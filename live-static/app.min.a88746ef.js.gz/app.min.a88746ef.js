// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"js/app.min.js":[function(require,module,exports) {
function email_test(e) {
  return !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,8})+$/.test(e.value);
}

let sliders = document.querySelectorAll("._swiper");

if (sliders) {
  for (let e = 0; e < sliders.length; e++) {
    let t = sliders[e];

    if (!t.classList.contains("swiper-bild")) {
      let e = t.children;
      if (e) for (let t = 0; t < e.length; t++) {
        e[t].classList.add("swiper-slide");
      }
      let l = t.innerHTML,
          n = document.createElement("div");

      if (n.classList.add("swiper-wrapper"), n.innerHTML = l, t.innerHTML = "", t.appendChild(n), t.classList.add("swiper-bild"), t.classList.contains("_swiper_scroll")) {
        let e = document.createElement("div");
        e.classList.add("swiper-scrollbar"), t.appendChild(e);
      }
    }

    t.classList.contains("_gallery");
  }

  sliders_bild_callback();
}

function sliders_bild_callback(e) {}

let sliderScrollItems = document.querySelectorAll("._swiper_scroll");
if (sliderScrollItems.length > 0) for (let e = 0; e < sliderScrollItems.length; e++) {
  const t = sliderScrollItems[e],
        l = t.querySelector(".swiper-scrollbar");
  new Swiper(t, {
    observer: !0,
    observeParents: !0,
    direction: "vertical",
    slidesPerView: "auto",
    freeMode: !0,
    scrollbar: {
      el: l,
      draggable: !0,
      snapOnRelease: !1
    },
    mousewheel: {
      releaseOnEdges: !0
    }
  }).scrollbar.updateSize();
}

function sliders_bild_callback(e) {}

function checkArrow(e) {
  var t = document.querySelector(".slider-aboutus .slider-arrow_prev"),
      l = document.querySelector(".slider-aboutus .slider-arrow_next");
  t.style.visibility = "visible", l.style.visibility = "visible", e.isBeginning && (t.style.visibility = "hidden"), e.isEnd && (l.style.visibility = "hidden");
}

document.querySelector(".slider-main__body") && new Swiper(".slider-main__body", {
  observer: !0,
  observeParents: !0,
  slidesPerView: 1,
  spaceBetween: 32,
  watchOverflow: !0,
  speed: 800,
  loop: !0,
  loopAdditionalSlides: 5,
  preloadImages: !1,
  parallax: !0,
  pagination: {
    el: ".controls-slider-main__dotts",
    clickable: !0
  },
  navigation: {
    nextEl: ".slider-main .slider-arrow_next",
    prevEl: ".slider-main .slider-arrow_prev"
  }
}), document.querySelector(".slider-sub-slider-big__body") && new Swiper(".slider-sub-slider-big__body", {
  observer: !0,
  observeParents: !0,
  slidesPerView: "auto",
  spaceBetween: 24,
  watchOverflow: !0,
  speed: 800,
  loop: !0,
  loopAdditionalSlides: 5,
  preloadImages: !1,
  parallax: !0,
  pagination: {
    el: ".slider-sub-slider-big__dotts",
    clickable: !0
  },
  navigation: {
    nextEl: ".slider-sub-slider-big .slider-arrow_next",
    prevEl: ".slider-sub-slider-big .slider-arrow_prev"
  }
}), document.querySelector(".slider-stocks__body") && new Swiper(".slider-stocks__body", {
  observer: !0,
  observeParents: !0,
  slidesPerView: 3,
  spaceBetween: 32,
  watchOverflow: !0,
  speed: 800,
  loop: !0,
  loopAdditionalSlides: 5,
  preloadImages: !1,
  parallax: !0,
  pagination: {
    el: ".slider-stocks__dotts",
    clickable: !0
  },
  navigation: {
    nextEl: ".slider-stocks .slider-arrow_next",
    prevEl: ".slider-stocks .slider-arrow_prev"
  },
  breakpoints: {
    320: {
      slidesPerView: 1.1,
      spaceBetween: 15
    },
    768: {
      slidesPerView: 2,
      spaceBetween: 20
    },
    992: {
      slidesPerView: 3,
      spaceBetween: 32
    }
  }
}), document.querySelector(".slider-aboutus__body") && new Swiper(".slider-aboutus__body", {
  observer: !0,
  observeParents: !0,
  slidesPerView: 1,
  watchOverflow: !0,
  spaceBetween: 20,
  speed: 800,
  loop: !1,
  loopAdditionalSlides: 5,
  preloadImages: !1,
  parallax: !0,
  pagination: {
    el: ".slider-aboutus__dotts",
    clickable: !0
  },
  navigation: {
    nextEl: ".slider-aboutus .slider-arrow_next",
    prevEl: ".slider-aboutus .slider-arrow_prev"
  },
  on: {
    init: function () {
      checkArrow(this);
    },
    slideChangeTransitionStart: function () {
      checkArrow(this);
    }
  }
});
var ua = window.navigator.userAgent,
    msie = ua.indexOf("MSIE "),
    isMobile = {
  Android: function () {
    return navigator.userAgent.match(/Android/i);
  },
  BlackBerry: function () {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  iOS: function () {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  Opera: function () {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  Windows: function () {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function () {
    return isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows();
  }
};

function isIE() {
  return (ua = navigator.userAgent).indexOf("MSIE ") > -1 || ua.indexOf("Trident/") > -1;
}

function testWebP(e) {
  var t = new Image();
  t.onload = t.onerror = function () {
    e(2 == t.height);
  }, t.src = "data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA";
}

function ibg() {
  if (isIE()) {
    let t = document.querySelectorAll("._ibg");

    for (var e = 0; e < t.length; e++) t[e].querySelector("img") && null != t[e].querySelector("img").getAttribute("src") && (t[e].style.backgroundImage = "url(" + t[e].querySelector("img").getAttribute("src") + ")");
  }
}

isIE() && document.querySelector("html").classList.add("ie"), isMobile.any() && document.querySelector("html").classList.add("_touch"), testWebP(function (e) {
  !0 === e ? document.querySelector("html").classList.add("_webp") : document.querySelector("html").classList.add("_no-webp");
}), ibg(), window.addEventListener("load", function () {
  document.querySelector(".wrapper") && setTimeout(function () {
    document.querySelector(".wrapper").classList.add("_loaded");
  }, 0);
});
let unlock = !0;

if (location.hash) {
  const e = location.hash.replace("#", "");
  document.querySelector(".popup_" + e) ? popup_open(e) : document.querySelector("div." + e) && _goto(document.querySelector("." + e), 500, "");
}

let iconMenu = document.querySelector(".icon-menu");

if (null != iconMenu) {
  let e = 500,
      t = document.querySelector(".menu__body");
  iconMenu.addEventListener("click", function (l) {
    unlock && (body_lock(e), iconMenu.classList.toggle("_active"), t.classList.toggle("_active"));
  });
}

function menu_close() {
  let e = document.querySelector(".icon-menu"),
      t = document.querySelector(".menu__body");
  e.classList.remove("_active"), t.classList.remove("_active");
}

function body_lock(e) {
  document.querySelector("body").classList.contains("_lock") ? body_lock_remove(e) : body_lock_add(e);
}

function body_lock_remove(e) {
  let t = document.querySelector("body");

  if (unlock) {
    let l = document.querySelectorAll("._lp");
    setTimeout(() => {
      for (let e = 0; e < l.length; e++) {
        l[e].style.paddingRight = "0px";
      }

      t.style.paddingRight = "0px", t.classList.remove("_lock");
    }, e), unlock = !1, setTimeout(function () {
      unlock = !0;
    }, e);
  }
}

function body_lock_add(e) {
  let t = document.querySelector("body");

  if (unlock) {
    let l = document.querySelectorAll("._lp");

    for (let e = 0; e < l.length; e++) {
      l[e].style.paddingRight = window.innerWidth - document.querySelector(".wrapper").offsetWidth + "px";
    }

    t.style.paddingRight = window.innerWidth - document.querySelector(".wrapper").offsetWidth + "px", t.classList.add("_lock"), unlock = !1, setTimeout(function () {
      unlock = !0;
    }, e);
  }
}

let title = document.querySelectorAll("._letter-animation");
if (title) for (let e = 0; e < title.length; e++) {
  let t = title[e],
      l = t.innerHTML.replace("  ", " ").split(" "),
      n = "";

  for (let e = 0; e < l.length; e++) {
    let i = l[e],
        o = i.length;
    n += "<p>";

    for (let e = 0; e < o; e++) {
      let t = i.substr(e, 1);
      " " == t && (t = "&nbsp;"), n = n + "<span>" + t + "</span>";
    }

    t.innerHTML = n, n += "&nbsp;</p>";
  }
}
let tabs = document.querySelectorAll("._tabs");

for (let e = 0; e < tabs.length; e++) {
  let t = tabs[e],
      l = t.querySelectorAll("._tabs-item"),
      n = t.querySelectorAll("._tabs-block");

  for (let e = 0; e < l.length; e++) {
    let t = l[e];
    t.addEventListener("click", function (i) {
      for (let e = 0; e < l.length; e++) {
        l[e].classList.remove("_active"), n[e].classList.remove("_active");
      }

      t.classList.add("_active"), n[e].classList.add("_active"), i.preventDefault();
    });
  }
}

const spollersArray = document.querySelectorAll("[data-spollers]");

if (spollersArray.length > 0) {
  const e = Array.from(spollersArray).filter(function (e, t, l) {
    return !e.dataset.spollers.split(",")[0];
  });
  e.length > 0 && initSpollers(e);
  const t = Array.from(spollersArray).filter(function (e, t, l) {
    return e.dataset.spollers.split(",")[0];
  });

  if (t.length > 0) {
    const e = [];
    t.forEach(t => {
      const l = {},
            n = t.dataset.spollers.split(",");
      l.value = n[0], l.type = n[1] ? n[1].trim() : "max", l.item = t, e.push(l);
    });
    let l = e.map(function (e) {
      return "(" + e.type + "-width: " + e.value + "px)," + e.value + "," + e.type;
    });
    l = l.filter(function (e, t, l) {
      return l.indexOf(e) === t;
    }), l.forEach(t => {
      const l = t.split(","),
            n = l[1],
            i = l[2],
            o = window.matchMedia(l[0]),
            r = e.filter(function (e) {
        if (e.value === n && e.type === i) return !0;
      });
      o.addListener(function () {
        initSpollers(r, o);
      }), initSpollers(r, o);
    });
  }

  function initSpollers(e, t = !1) {
    e.forEach(e => {
      e = t ? e.item : e, t.matches || !t ? (e.classList.add("_init"), initSpollerBody(e), e.addEventListener("click", setSpollerAction)) : (e.classList.remove("_init"), initSpollerBody(e, !1), e.removeEventListener("click", setSpollerAction));
    });
  }

  function initSpollerBody(e, t = !0) {
    const l = e.querySelectorAll("[data-spoller]");
    l.length > 0 && l.forEach(e => {
      t ? (e.removeAttribute("tabindex"), e.classList.contains("_active") || null != e.nextElementSibling && (e.nextElementSibling.hidden = !0)) : (e.setAttribute("tabindex", "-1"), null != e.nextElementSibling && (e.nextElementSibling.hidden = !1));
    });
  }

  function setSpollerAction(e) {
    const t = e.target;

    if (t.hasAttribute("data-spoller") || t.closest("[data-spoller]")) {
      const l = t.hasAttribute("data-spoller") ? t : t.closest("[data-spoller]"),
            n = l.closest("[data-spollers]"),
            i = !!n.hasAttribute("data-one-spoller");
      n.querySelectorAll("._slide").length || (i && !l.classList.contains("_active") && hideSpollersBody(n), l.classList.toggle("_active"), _slideToggle(l.nextElementSibling, 500)), e.preventDefault();
    }
  }

  function hideSpollersBody(e) {
    const t = e.querySelector("[data-spoller]._active");
    t && (t.classList.remove("_active"), _slideUp(t.nextElementSibling, 500));
  }
}

let gallery = document.querySelectorAll("._gallery");

function gallery_init() {
  for (let e = 0; e < gallery.length; e++) {
    const t = gallery[e];
    lightGallery(t, {
      counter: !1,
      selector: "a",
      download: !1
    });
  }
}

function search_in_list(e) {
  let t = e.parentNode.querySelector("ul").querySelectorAll("li"),
      l = e.value.toUpperCase();

  for (i = 0; i < t.length; i++) {
    let e = t[i],
        n = e;
    txtValue = n.textContent || n.innerText, txtValue.toUpperCase().indexOf(l) > -1 ? e.style.display = "" : e.style.display = "none";
  }
}

function digi(e) {
  return e.toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, "$1 ");
}

function digi_animate(e) {
  if (e.length > 0) for (let t = 0; t < e.length; t++) {
    const l = e[t],
          n = parseInt(l.innerHTML.replace(" ", ""));
    l.classList.contains("_done") || digi_animate_value(l, 0, n, 1500);
  }
}

function digi_animate_value(e, t, l, n) {
  var i = e,
      o = l - t,
      r = Math.abs(Math.floor(n / o));
  r = Math.max(r, 50);
  var s,
      a = new Date().getTime() + n;

  function c() {
    var e = new Date().getTime(),
        t = Math.max((a - e) / n, 0),
        r = Math.round(l - t * o);
    i.innerHTML = digi(r), r == l && clearInterval(s);
  }

  s = setInterval(c, r), c(), e.classList.add("_done");
}

gallery && gallery_init();
let popup_link = document.querySelectorAll("._popup-link"),
    popups = document.querySelectorAll(".popup");

for (let e = 0; e < popup_link.length; e++) {
  const t = popup_link[e];
  t.addEventListener("click", function (e) {
    if (unlock) {
      popup_open(t.getAttribute("href").replace("#", ""), t.getAttribute("data-video"));
    }

    e.preventDefault();
  });
}

for (let e = 0; e < popups.length; e++) {
  popups[e].addEventListener("click", function (e) {
    e.target.closest(".popup__body") || popup_close(e.target.closest(".popup"));
  });
}

function popup_open(e, t = "") {
  document.querySelectorAll(".popup._active").length > 0 && popup_close("", !1);
  let l = document.querySelector(".popup_" + e);

  if (l && unlock) {
    if ("" != t && null != t) {
      document.querySelector(".popup_video").querySelector(".popup__video").innerHTML = '<iframe src="https://www.youtube.com/embed/' + t + '?autoplay=1"  allow="autoplay; encrypted-media" allowfullscreen></iframe>';
    }

    document.querySelector(".menu__body._active") || body_lock_add(500), l.classList.add("_active"), history.pushState("", "", "#" + e);
  }
}

function popup_close(e, t = !0) {
  if (unlock) {
    if (e) {
      let t = e.querySelector(".popup__video");
      t && (t.innerHTML = ""), e.classList.remove("_active");
    } else for (let e = 0; e < popups.length; e++) {
      const t = popups[e];
      let l = t.querySelector(".popup__video");
      l && (l.innerHTML = ""), t.classList.remove("_active");
    }

    !document.querySelector(".menu__body._active") && t && body_lock_remove(500), history.pushState("", "", window.location.href.split("#")[0]);
  }
}

let popup_close_icon = document.querySelectorAll(".popup__close,._popup-close");
if (popup_close_icon) for (let e = 0; e < popup_close_icon.length; e++) {
  const t = popup_close_icon[e];
  t.addEventListener("click", function () {
    popup_close(t.closest(".popup"));
  });
}
document.addEventListener("keydown", function (e) {
  "Escape" === e.code && popup_close();
});

let _slideUp = (e, t = 500) => {
  e.classList.contains("_slide") || (e.classList.add("_slide"), e.style.transitionProperty = "height, margin, padding", e.style.transitionDuration = t + "ms", e.style.height = e.offsetHeight + "px", e.offsetHeight, e.style.overflow = "hidden", e.style.height = 0, e.style.paddingTop = 0, e.style.paddingBottom = 0, e.style.marginTop = 0, e.style.marginBottom = 0, window.setTimeout(() => {
    e.hidden = !0, e.style.removeProperty("height"), e.style.removeProperty("padding-top"), e.style.removeProperty("padding-bottom"), e.style.removeProperty("margin-top"), e.style.removeProperty("margin-bottom"), e.style.removeProperty("overflow"), e.style.removeProperty("transition-duration"), e.style.removeProperty("transition-property"), e.classList.remove("_slide");
  }, t));
},
    _slideDown = (e, t = 500) => {
  if (!e.classList.contains("_slide")) {
    e.classList.add("_slide"), e.hidden && (e.hidden = !1);
    let l = e.offsetHeight;
    e.style.overflow = "hidden", e.style.height = 0, e.style.paddingTop = 0, e.style.paddingBottom = 0, e.style.marginTop = 0, e.style.marginBottom = 0, e.offsetHeight, e.style.transitionProperty = "height, margin, padding", e.style.transitionDuration = t + "ms", e.style.height = l + "px", e.style.removeProperty("padding-top"), e.style.removeProperty("padding-bottom"), e.style.removeProperty("margin-top"), e.style.removeProperty("margin-bottom"), window.setTimeout(() => {
      e.style.removeProperty("height"), e.style.removeProperty("overflow"), e.style.removeProperty("transition-duration"), e.style.removeProperty("transition-property"), e.classList.remove("_slide");
    }, t);
  }
},
    _slideToggle = (e, t = 500) => e.hidden ? _slideDown(e, t) : _slideUp(e, t);

function _wrap(e, t) {
  e.parentNode.insertBefore(t, e), t.appendChild(e);
}

function _removeClasses(e, t) {
  for (var l = 0; l < e.length; l++) e[l].classList.remove(t);
}

function _is_hidden(e) {
  return null === e.offsetParent;
}

let moreBlocks = document.querySelectorAll("._more-block");

if (moreBlocks.length > 0) {
  let e = document.querySelector(".wrapper");

  for (let t = 0; t < moreBlocks.length; t++) {
    const l = moreBlocks[t];
    let n = l.querySelectorAll("._more-item");

    if (n.length > 0) {
      let t,
          i = l.querySelector("._more-link"),
          o = l.querySelector("._more-content"),
          r = o.getAttribute("data-view");

      function setSize(l) {
        let i,
            s = 0,
            a = 0;

        for (let e = 0; e < n.length; e++) e < r && (s += n[e].offsetHeight), a += n[e].offsetHeight;

        i = "start" === l ? a : s, t = window.innerWidth - e.offsetWidth, o.style.height = i + "px";
      }

      function updateSize() {
        let l = window.innerWidth - e.offsetWidth;
        (0 === t && l > 0 || t > 0 && 0 === l) && (i.classList.contains("_active") ? setSize("start") : setSize());
      }

      "0s" === getComputedStyle(o).getPropertyValue("transition-duration") && (o.style.cssText = "transition-duration: 1ms"), i.addEventListener("click", function (e) {
        i.classList.contains("_active") ? setSize() : setSize("start"), i.classList.toggle("_active"), e.preventDefault();
      }), o.addEventListener("transitionend", updateSize, !1), window.addEventListener("resize", function (e) {
        i.classList.contains("_active") ? setSize("start") : setSize();
      }), setSize();
    }
  }
}

const ratings = document.querySelectorAll(".rating");

function initRatings() {
  let e, t;

  for (let e = 0; e < ratings.length; e++) {
    l(ratings[e]);
  }

  function l(e) {
    n(e), i(), e.classList.contains("rating_set") && function (e) {
      const l = e.querySelectorAll(".rating__item");

      for (let r = 0; r < l.length; r++) {
        const s = l[r];
        s.addEventListener("mouseenter", function (t) {
          n(e), i(s.value);
        }), s.addEventListener("mouseleave", function (e) {
          i();
        }), s.addEventListener("click", function (l) {
          n(e), e.dataset.ajax ? o(s.value, e) : (t.innerHTML = r + 1, i());
        });
      }
    }(e);
  }

  function n(l) {
    e = l.querySelector(".rating__active"), t = l.querySelector(".rating__value");
  }

  function i(l = t.innerHTML) {
    const n = l / .05;
    e.style.width = n + "%";
  }

  async function o(e, l) {
    if (!l.classList.contains("rating_sending")) {
      l.classList.add("rating_sending");
      let e = await fetch("rating.json", {
        method: "GET"
      });

      if (e.ok) {
        const n = (await e.json()).newRating;
        t.innerHTML = n, i(), l.classList.remove("rating_sending");
      } else alert("Ошибка"), l.classList.remove("rating_sending");
    }
  }
}

function animate({
  timing: e,
  draw: t,
  duration: l
}) {
  let n = performance.now();
  requestAnimationFrame(function i(o) {
    let r = (o - n) / l;
    r > 1 && (r = 1);
    let s = e(r);
    t(s), r < 1 && requestAnimationFrame(i);
  });
}

function makeEaseOut(e) {
  return function (t) {
    return 1 - e(1 - t);
  };
}

function makeEaseInOut(e) {
  return function (t) {
    return t < .5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2;
  };
}

function quad(e) {
  return Math.pow(e, 2);
}

function circ(e) {
  return 1 - Math.sin(Math.acos(e));
}

ratings.length > 0 && initRatings(), Element.prototype.closest || (Element.prototype.closest = function (e) {
  for (var t = this; t;) {
    if (t.matches(e)) return t;
    t = t.parentElement;
  }

  return null;
}), Element.prototype.matches || (Element.prototype.matches = Element.prototype.matchesSelector || Element.prototype.webkitMatchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector), window.onload = function () {
  document.addEventListener("click", function (e) {
    const t = e.target;
    window.innerWidth > 768 && isMobile.any() && (t.classList.contains("menu__arrow") && (t.closest(".menu__item").classList.contains("_hover") || document.querySelectorAll(".menu__item._hover").length > 0 && _removeClasses(document.querySelectorAll(".menu__item._hover"), "_hover"), t.closest(".menu__item").classList.toggle("_hover")), !t.closest(".menu__item") && document.querySelectorAll(".menu__item._hover").length > 0 && _removeClasses(document.querySelectorAll(".menu__item._hover"), "_hover"));
    t.classList.contains("search-form__icon") ? document.querySelector(".search-form").classList.toggle("_active") : !t.closest(".search-form") && document.querySelectorAll(".search-form._active").length > 0 && _removeClasses(document.querySelectorAll(".search-form._active"), "_active");
  });
  const e = document.querySelector(".header");
  new IntersectionObserver(function (t, l) {
    t[0].isIntersecting ? e.classList.remove("_scroll") : e.classList.add("_scroll");
  }).observe(e);

  const t = document.querySelector(".product-info__fixed-wrapper"),
        l = function (e, l) {
    e[0].isIntersecting ? t.classList.remove("_scroll") : t.classList.add("_scroll");
  };

  if (null != t) {
    new IntersectionObserver(l).observe(t);
  }
};
let forms = document.querySelectorAll("form");
if (forms.length > 0) for (let e = 0; e < forms.length; e++) {
  forms[e].addEventListener("submit", form_submit);
}

async function form_submit(e) {
  let t = e.target.closest("form");

  if (0 == form_validate(t)) {
    let l = t.getAttribute("action") ? t.getAttribute("action").trim() : "#",
        n = t.getAttribute("method") ? t.getAttribute("method").trim() : "GET";
    const i = t.getAttribute("data-message");

    if (t.getAttribute("data-ajax")) {
      e.preventDefault();
      let o = new FormData(t);
      t.classList.add("_sending");
      let r = await fetch(l, {
        method: n,
        body: o
      });

      if (r.ok) {
        await r.json();
        t.classList.remove("_sending"), i && popup_open(i + "-message"), form_clean(t);
      } else alert("Ошибка"), t.classList.remove("_sending");
    }

    t.hasAttribute("data-test") && (e.preventDefault(), popup_open(i + "-message"), form_clean(t));
  } else {
    let l = t.querySelectorAll("._error");
    l && t.classList.contains("_goto-error") && _goto(l[0], 1e3, 50), e.preventDefault();
  }
}

function form_validate(e) {
  let t = 0,
      l = e.querySelectorAll("._req");
  if (l.length > 0) for (let e = 0; e < l.length; e++) {
    const n = l[e];
    _is_hidden(n) || (t += form_validate_input(n));
  }
  return t;
}

function form_validate_input(e) {
  let t = 0,
      l = e.getAttribute("data-value");

  if ("email" == e.getAttribute("name") || e.classList.contains("_email")) {
    if (e.value != l) {
      let t = e.value.replace(" ", "");
      e.value = t;
    }

    email_test(e) || e.value == l ? (form_add_error(e), t++) : form_remove_error(e);
  } else "checkbox" == e.getAttribute("type") && 0 == e.checked || "" == e.value || e.value == l ? (form_add_error(e), t++) : form_remove_error(e);

  return t;
}

function form_add_error(e) {
  e.classList.add("_error"), e.parentElement.classList.add("_error");
  let t = e.parentElement.querySelector(".form__error");
  t && e.parentElement.removeChild(t);
  let l = e.getAttribute("data-error");
  l && "" != l && e.parentElement.insertAdjacentHTML("beforeend", '<div class="form__error">' + l + "</div>");
}

function form_remove_error(e) {
  e.classList.remove("_error"), e.parentElement.classList.remove("_error");
  let t = e.parentElement.querySelector(".form__error");
  t && e.parentElement.removeChild(t);
}

function form_clean(e) {
  let t = e.querySelectorAll("input,textarea");

  for (let e = 0; e < t.length; e++) {
    const l = t[e];
    l.parentElement.classList.remove("_focus"), l.classList.remove("_focus"), l.value = l.getAttribute("data-value");
  }

  let l = e.querySelectorAll(".checkbox__input");
  if (l.length > 0) for (let e = 0; e < l.length; e++) {
    l[e].checked = !1;
  }
  let n = e.querySelectorAll("select");
  if (n.length > 0) for (let e = 0; e < n.length; e++) {
    const t = n[e],
          l = t.getAttribute("data-default");
    t.value = l, select_item(t);
  }
}

let viewPass = document.querySelectorAll(".form__viewpass");

for (let e = 0; e < viewPass.length; e++) {
  const t = viewPass[e];
  t.addEventListener("click", function (e) {
    t.classList.contains("_active") ? t.parentElement.querySelector("input").setAttribute("type", "password") : t.parentElement.querySelector("input").setAttribute("type", "text"), t.classList.toggle("_active");
  });
}

let selects = document.getElementsByTagName("select");

function selects_init() {
  for (let e = 0; e < selects.length; e++) {
    select_init(selects[e]);
  }

  document.addEventListener("click", function (e) {
    selects_close(e);
  }), document.addEventListener("keydown", function (e) {
    "Escape" === e.code && selects_close(e);
  });
}

function selects_close(e) {
  const t = document.querySelectorAll(".select");
  if (!e.target.closest(".select") && !e.target.classList.contains("_option")) for (let e = 0; e < t.length; e++) {
    const l = t[e],
          n = l.querySelector(".select__options");
    l.classList.remove("_active"), _slideUp(n, 100);
  }
}

function select_init(e) {
  const t = e.parentElement,
        l = e.getAttribute("class"),
        n = e.querySelector("option:checked");
  e.setAttribute("data-default", n.value), e.style.display = "none", t.insertAdjacentHTML("beforeend", '<div class="select select_' + l + '"></div>'), e.parentElement.querySelector(".select").appendChild(e), select_item(e);
}

function select_item(e) {
  const t = e.parentElement,
        l = t.querySelector(".select__item"),
        n = e.querySelectorAll("option"),
        i = e.querySelector("option:checked").text,
        o = e.getAttribute("data-type");
  l && l.remove();
  let r = "";
  r = "input" == o ? '<div class="select__value icon-select-arrow"><input autocomplete="off" type="text" name="form[]" value="' + i + '" data-error="Ошибка" data-value="' + i + '" class="select__input"></div>' : '<div class="select__value icon-select-arrow"><span>' + i + "</span></div>", t.insertAdjacentHTML("beforeend", '<div class="select__item"><div class="select__title">' + r + '</div><div hidden class="select__options">' + select_get_options(n) + "</div></div></div>"), select_actions(e, t);
}

function select_actions(e, t) {
  const l = t.querySelector(".select__item"),
        n = t.querySelector(".select__title"),
        i = t.querySelector(".select__options"),
        o = t.querySelectorAll(".select__option"),
        r = e.getAttribute("data-type"),
        s = t.querySelector(".select__input");

  function a() {
    let l = t.querySelectorAll(".select__option"),
        n = e.querySelectorAll("option"),
        i = [];

    for (let e = 0; e < l.length; e++) {
      const t = l[e];

      if (n[e].removeAttribute("selected"), t.classList.contains("_selected")) {
        const l = t.innerHTML;
        i.push(l), n[e].setAttribute("selected", "selected");
      }
    }

    t.querySelector(".select__value").innerHTML = "<span>" + i + "</span>";
  }

  function c(e) {
    if (!e) {
      let e = document.querySelectorAll(".select");

      for (let t = 0; t < e.length; t++) {
        const n = e[t],
              i = n.querySelector(".select__options");
        n != l.closest(".select") && (n.classList.remove("_active"), _slideUp(i, 100));
      }

      _slideToggle(i, 100), t.classList.toggle("_active");
    }
  }

  n.addEventListener("click", function (e) {
    c();
  });

  for (let l = 0; l < o.length; l++) {
    const n = o[l],
          i = n.getAttribute("data-value"),
          d = n.innerHTML;
    "input" == r ? s.addEventListener("keyup", select_search) : n.getAttribute("data-value") != e.value || e.hasAttribute("multiple") || (n.style.display = "none"), n.addEventListener("click", function () {
      for (let e = 0; e < o.length; e++) {
        o[e].style.display = "block";
      }

      let l;
      "input" == r ? (s.value = d, e.value = i) : e.hasAttribute("multiple") ? (n.classList.toggle("_selected"), a()) : (t.querySelector(".select__value").innerHTML = "<span>" + d + "</span>", e.value = i, n.style.display = "none"), e.hasAttribute("multiple") && (l = "multiple"), c(l);
    });
  }
}

function select_get_options(e) {
  if (e) {
    let t = "";

    for (let l = 0; l < e.length; l++) {
      const n = e[l],
            i = n.value;

      if ("" != i) {
        t = t + '<div data-value="' + i + '" class="select__option">' + n.innerHTML + "</div>";
      }
    }

    return t;
  }
}

function select_search(e) {
  e.target.closest(".select ").querySelector(".select__options");
  let t = e.target.closest(".select ").querySelectorAll(".select__option"),
      l = e.target.value.toUpperCase();

  for (let e = 0; e < t.length; e++) {
    let n = t[e];
    (n.textContent || n.innerText).toUpperCase().indexOf(l) > -1 ? n.style.display = "" : n.style.display = "none";
  }
}

function selects_update_all() {
  let e = document.querySelectorAll("select");
  if (e) for (let t = 0; t < e.length; t++) {
    select_item(e[t]);
  }
}

selects.length > 0 && selects_init();
let inputs = document.querySelectorAll("input[data-value],textarea[data-value]");

function inputs_init(e) {
  if (e.length > 0) for (let t = 0; t < e.length; t++) {
    const l = e[t],
          n = l.getAttribute("data-value");

    if (input_placeholder_add(l), "" != l.value && l.value != n && input_focus_add(l), l.addEventListener("focus", function (e) {
      l.value == n && (input_focus_add(l), l.value = ""), "pass" !== l.getAttribute("data-type") || l.parentElement.querySelector(".form__viewpass").classList.contains("_active") || l.setAttribute("type", "password"), l.classList.contains("_date"), l.classList.contains("_phone") && (l.classList.add("_mask"), Inputmask("+375 (99) 9999999", {
        clearIncomplete: !0,
        clearMaskOnLostFocus: !0,
        onincomplete: function () {
          input_clear_mask(l, n);
        }
      }).mask(l)), l.classList.contains("_digital") && (l.classList.add("_mask"), Inputmask("9{1,}", {
        placeholder: "",
        clearIncomplete: !0,
        clearMaskOnLostFocus: !0,
        onincomplete: function () {
          input_clear_mask(l, n);
        }
      }).mask(l)), form_remove_error(l);
    }), l.addEventListener("blur", function (e) {
      "" == l.value && (l.value = n, input_focus_remove(l), l.classList.contains("_mask") && input_clear_mask(l, n), "pass" === l.getAttribute("data-type") && l.setAttribute("type", "text"));
    }), l.classList.contains("_date")) {
      const e = datepicker(l, {
        customDays: ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"],
        customMonths: ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"],
        overlayButton: "Применить",
        overlayPlaceholder: "Год (4 цифры)",
        startDay: 1,
        formatter: (e, t, l) => {
          const n = t.toLocaleDateString();
          e.value = n;
        },
        onSelect: function (e, t, l) {
          input_focus_add(e.el);
        }
      }),
            t = l.getAttribute("data-from"),
            n = l.getAttribute("data-to");
      t && e.setMin(new Date(t)), n && e.setMax(new Date(n));
    }
  }
}

function input_placeholder_add(e) {
  const t = e.getAttribute("data-value");
  "" == e.value && "" != t && (e.value = t);
}

function input_focus_add(e) {
  e.classList.add("_focus"), e.parentElement.classList.add("_focus");
}

function input_focus_remove(e) {
  e.classList.remove("_focus"), e.parentElement.classList.remove("_focus");
}

function input_clear_mask(e, t) {
  e.inputmask.remove(), e.value = t, input_focus_remove(e);
}

inputs_init(inputs);
let quantityButtons = document.querySelectorAll(".quantity__button");
if (quantityButtons.length > 0) for (let e = 0; e < quantityButtons.length; e++) {
  const t = quantityButtons[e];
  t.addEventListener("click", function (e) {
    let l = parseInt(t.closest(".quantity").querySelector("input").value);
    t.classList.contains("quantity__button_plus") ? l++ : (l -= 1, l < 1 && (l = 1)), t.closest(".quantity").querySelector("input").value = l;
  });
}
const priceSlider = document.querySelector(".price-filter__slider");

if (priceSlider) {
  let e = priceSlider.getAttribute("data-from"),
      t = priceSlider.getAttribute("data-to");

  function setPriceValues() {
    let e, t;
    "" != priceStart.value && (e = priceStart.value), "" != priceEnd.value && (t = priceEnd.value), priceSlider.noUiSlider.set([e, t]);
  }

  noUiSlider.create(priceSlider, {
    start: [0, 2e5],
    connect: !0,
    tooltips: [wNumb({
      decimals: 0,
      prefix: e + " "
    }), wNumb({
      decimals: 0,
      prefix: t + " "
    })],
    range: {
      min: [0],
      max: [2e5]
    }
  });
}

function DynamicAdapt(e) {
  this.type = e;
}

DynamicAdapt.prototype.init = function () {
  const e = this;
  this.оbjects = [], this.daClassname = "_dynamic_adapt_", this.nodes = document.querySelectorAll("[data-da]");

  for (let e = 0; e < this.nodes.length; e++) {
    const t = this.nodes[e],
          l = t.dataset.da.trim().split(","),
          n = {};
    n.element = t, n.parent = t.parentNode, n.destination = document.querySelector(l[0].trim()), n.breakpoint = l[1] ? l[1].trim() : "767", n.place = l[2] ? l[2].trim() : "last", n.index = this.indexInParent(n.parent, n.element), this.оbjects.push(n);
  }

  this.arraySort(this.оbjects), this.mediaQueries = Array.prototype.map.call(this.оbjects, function (e) {
    return "(" + this.type + "-width: " + e.breakpoint + "px)," + e.breakpoint;
  }, this), this.mediaQueries = Array.prototype.filter.call(this.mediaQueries, function (e, t, l) {
    return Array.prototype.indexOf.call(l, e) === t;
  });

  for (let t = 0; t < this.mediaQueries.length; t++) {
    const l = this.mediaQueries[t],
          n = String.prototype.split.call(l, ","),
          i = window.matchMedia(n[0]),
          o = n[1],
          r = Array.prototype.filter.call(this.оbjects, function (e) {
      return e.breakpoint === o;
    });
    i.addListener(function () {
      e.mediaHandler(i, r);
    }), this.mediaHandler(i, r);
  }
}, DynamicAdapt.prototype.mediaHandler = function (e, t) {
  if (e.matches) for (let e = 0; e < t.length; e++) {
    const l = t[e];
    l.index = this.indexInParent(l.parent, l.element), this.moveTo(l.place, l.element, l.destination);
  } else for (let e = 0; e < t.length; e++) {
    const l = t[e];
    l.element.classList.contains(this.daClassname) && this.moveBack(l.parent, l.element, l.index);
  }
}, DynamicAdapt.prototype.moveTo = function (e, t, l) {
  t.classList.add(this.daClassname), "last" === e || e >= l.children.length ? l.insertAdjacentElement("beforeend", t) : "first" !== e ? l.children[e].insertAdjacentElement("beforebegin", t) : l.insertAdjacentElement("afterbegin", t);
}, DynamicAdapt.prototype.moveBack = function (e, t, l) {
  t.classList.remove(this.daClassname), void 0 !== e.children[l] ? e.children[l].insertAdjacentElement("beforebegin", t) : e.insertAdjacentElement("beforeend", t);
}, DynamicAdapt.prototype.indexInParent = function (e, t) {
  const l = Array.prototype.slice.call(e.children);
  return Array.prototype.indexOf.call(l, t);
}, DynamicAdapt.prototype.arraySort = function (e) {
  "min" === this.type ? Array.prototype.sort.call(e, function (e, t) {
    return e.breakpoint === t.breakpoint ? e.place === t.place ? 0 : "first" === e.place || "last" === t.place ? -1 : "last" === e.place || "first" === t.place ? 1 : e.place - t.place : e.breakpoint - t.breakpoint;
  }) : Array.prototype.sort.call(e, function (e, t) {
    return e.breakpoint === t.breakpoint ? e.place === t.place ? 0 : "first" === e.place || "last" === t.place ? 1 : "last" === e.place || "first" === t.place ? -1 : t.place - e.place : t.breakpoint - e.breakpoint;
  });
};
const da = new DynamicAdapt("max");
da.init();
},{}],"../../node_modules/parcel-bundler/src/builtins/hmr-runtime.js":[function(require,module,exports) {
var global = arguments[3];
var OVERLAY_ID = '__parcel__error__overlay__';
var OldModule = module.bundle.Module;

function Module(moduleName) {
  OldModule.call(this, moduleName);
  this.hot = {
    data: module.bundle.hotData,
    _acceptCallbacks: [],
    _disposeCallbacks: [],
    accept: function (fn) {
      this._acceptCallbacks.push(fn || function () {});
    },
    dispose: function (fn) {
      this._disposeCallbacks.push(fn);
    }
  };
  module.bundle.hotData = null;
}

module.bundle.Module = Module;
var checkedAssets, assetsToAccept;
var parent = module.bundle.parent;

if ((!parent || !parent.isParcelRequire) && typeof WebSocket !== 'undefined') {
  var hostname = "" || location.hostname;
  var protocol = location.protocol === 'https:' ? 'wss' : 'ws';
  var ws = new WebSocket(protocol + '://' + hostname + ':' + "59258" + '/');

  ws.onmessage = function (event) {
    checkedAssets = {};
    assetsToAccept = [];
    var data = JSON.parse(event.data);

    if (data.type === 'update') {
      var handled = false;
      data.assets.forEach(function (asset) {
        if (!asset.isNew) {
          var didAccept = hmrAcceptCheck(global.parcelRequire, asset.id);

          if (didAccept) {
            handled = true;
          }
        }
      }); // Enable HMR for CSS by default.

      handled = handled || data.assets.every(function (asset) {
        return asset.type === 'css' && asset.generated.js;
      });

      if (handled) {
        console.clear();
        data.assets.forEach(function (asset) {
          hmrApply(global.parcelRequire, asset);
        });
        assetsToAccept.forEach(function (v) {
          hmrAcceptRun(v[0], v[1]);
        });
      } else if (location.reload) {
        // `location` global exists in a web worker context but lacks `.reload()` function.
        location.reload();
      }
    }

    if (data.type === 'reload') {
      ws.close();

      ws.onclose = function () {
        location.reload();
      };
    }

    if (data.type === 'error-resolved') {
      console.log('[parcel] ✨ Error resolved');
      removeErrorOverlay();
    }

    if (data.type === 'error') {
      console.error('[parcel] 🚨  ' + data.error.message + '\n' + data.error.stack);
      removeErrorOverlay();
      var overlay = createErrorOverlay(data);
      document.body.appendChild(overlay);
    }
  };
}

function removeErrorOverlay() {
  var overlay = document.getElementById(OVERLAY_ID);

  if (overlay) {
    overlay.remove();
  }
}

function createErrorOverlay(data) {
  var overlay = document.createElement('div');
  overlay.id = OVERLAY_ID; // html encode message and stack trace

  var message = document.createElement('div');
  var stackTrace = document.createElement('pre');
  message.innerText = data.error.message;
  stackTrace.innerText = data.error.stack;
  overlay.innerHTML = '<div style="background: black; font-size: 16px; color: white; position: fixed; height: 100%; width: 100%; top: 0px; left: 0px; padding: 30px; opacity: 0.85; font-family: Menlo, Consolas, monospace; z-index: 9999;">' + '<span style="background: red; padding: 2px 4px; border-radius: 2px;">ERROR</span>' + '<span style="top: 2px; margin-left: 5px; position: relative;">🚨</span>' + '<div style="font-size: 18px; font-weight: bold; margin-top: 20px;">' + message.innerHTML + '</div>' + '<pre>' + stackTrace.innerHTML + '</pre>' + '</div>';
  return overlay;
}

function getParents(bundle, id) {
  var modules = bundle.modules;

  if (!modules) {
    return [];
  }

  var parents = [];
  var k, d, dep;

  for (k in modules) {
    for (d in modules[k][1]) {
      dep = modules[k][1][d];

      if (dep === id || Array.isArray(dep) && dep[dep.length - 1] === id) {
        parents.push(k);
      }
    }
  }

  if (bundle.parent) {
    parents = parents.concat(getParents(bundle.parent, id));
  }

  return parents;
}

function hmrApply(bundle, asset) {
  var modules = bundle.modules;

  if (!modules) {
    return;
  }

  if (modules[asset.id] || !bundle.parent) {
    var fn = new Function('require', 'module', 'exports', asset.generated.js);
    asset.isNew = !modules[asset.id];
    modules[asset.id] = [fn, asset.deps];
  } else if (bundle.parent) {
    hmrApply(bundle.parent, asset);
  }
}

function hmrAcceptCheck(bundle, id) {
  var modules = bundle.modules;

  if (!modules) {
    return;
  }

  if (!modules[id] && bundle.parent) {
    return hmrAcceptCheck(bundle.parent, id);
  }

  if (checkedAssets[id]) {
    return;
  }

  checkedAssets[id] = true;
  var cached = bundle.cache[id];
  assetsToAccept.push([bundle, id]);

  if (cached && cached.hot && cached.hot._acceptCallbacks.length) {
    return true;
  }

  return getParents(global.parcelRequire, id).some(function (id) {
    return hmrAcceptCheck(global.parcelRequire, id);
  });
}

function hmrAcceptRun(bundle, id) {
  var cached = bundle.cache[id];
  bundle.hotData = {};

  if (cached) {
    cached.hot.data = bundle.hotData;
  }

  if (cached && cached.hot && cached.hot._disposeCallbacks.length) {
    cached.hot._disposeCallbacks.forEach(function (cb) {
      cb(bundle.hotData);
    });
  }

  delete bundle.cache[id];
  bundle(id);
  cached = bundle.cache[id];

  if (cached && cached.hot && cached.hot._acceptCallbacks.length) {
    cached.hot._acceptCallbacks.forEach(function (cb) {
      cb();
    });

    return true;
  }
}
},{}]},{},["../../node_modules/parcel-bundler/src/builtins/hmr-runtime.js","js/app.min.js"], null)
//# sourceMappingURL=/app.min.a88746ef.js.map